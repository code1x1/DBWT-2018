﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class MahlzeitenZutaten
    {
        public int Idzutaten { get; set; }
        public int Idmahlzeiten { get; set; }
        public int Id { get; set; }

        public virtual Mahlzeiten IdmahlzeitenNavigation { get; set; }
        public virtual Zutaten IdzutatenNavigation { get; set; }
    }
}
