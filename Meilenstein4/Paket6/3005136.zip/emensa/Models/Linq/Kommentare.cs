﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Kommentare
    {
        public int Id { get; set; }
        public int FkStudentId { get; set; }
        public int? FkzuMahlzeit { get; set; }
        public string Bemerkung { get; set; }
        public int Bewertung { get; set; }

        public virtual Student FkStudent { get; set; }
        public virtual Mahlzeiten FkzuMahlzeitNavigation { get; set; }
    }
}
