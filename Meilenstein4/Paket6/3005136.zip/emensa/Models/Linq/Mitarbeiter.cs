﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Mitarbeiter
    {
        public int Büro { get; set; }
        public int Telefon { get; set; }
        public int FkFhange { get; set; }
        public int Id { get; set; }

        public virtual FhAngehörige FkFhangeNavigation { get; set; }
    }
}
