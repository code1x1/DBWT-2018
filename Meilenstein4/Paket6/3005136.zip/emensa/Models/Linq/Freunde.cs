﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Freunde
    {
        public int Nutzer { get; set; }
        public int Freund { get; set; }
        public int Id { get; set; }

        public virtual Benutzer FreundNavigation { get; set; }
        public virtual Benutzer NutzerNavigation { get; set; }
    }
}
