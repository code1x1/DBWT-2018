﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Fachbereiche
    {
        public Fachbereiche()
        {
            GehörtZuFachbereiche = new HashSet<GehörtZuFachbereiche>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string Website { get; set; }
        public string Adresse { get; set; }

        public virtual ICollection<GehörtZuFachbereiche> GehörtZuFachbereiche { get; set; }
    }
}
