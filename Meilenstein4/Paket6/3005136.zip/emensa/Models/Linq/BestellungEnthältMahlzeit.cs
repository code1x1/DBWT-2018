﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class BestellungEnthältMahlzeit
    {
        public int Anzahl { get; set; }
        public int FkMahlzeit { get; set; }
        public int FkBestellungen { get; set; }
        public int Id { get; set; }

        public virtual Bestellungen FkBestellungenNavigation { get; set; }
        public virtual Mahlzeiten FkMahlzeitNavigation { get; set; }
    }
}
