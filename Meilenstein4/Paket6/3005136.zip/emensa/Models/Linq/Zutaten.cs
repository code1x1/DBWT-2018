﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Zutaten
    {
        public Zutaten()
        {
            MahlzeitenZutaten = new HashSet<MahlzeitenZutaten>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public byte Bio { get; set; }
        public byte Vegetarisch { get; set; }
        public byte Vegan { get; set; }
        public byte Glutenfrei { get; set; }

        public virtual ICollection<MahlzeitenZutaten> MahlzeitenZutaten { get; set; }
    }
}
