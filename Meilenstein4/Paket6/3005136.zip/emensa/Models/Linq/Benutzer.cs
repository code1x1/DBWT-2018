﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Benutzer
    {
        public Benutzer()
        {
            Bestellungen = new HashSet<Bestellungen>();
            FhAngehörige = new HashSet<FhAngehörige>();
            FreundeFreundNavigation = new HashSet<Freunde>();
            FreundeNutzerNavigation = new HashSet<Freunde>();
            Gäste = new HashSet<Gäste>();
        }

        public int Nummer { get; set; }
        public string Nutzername { get; set; }
        public DateTimeOffset? LetzerLogin { get; set; }
        public string EMail { get; set; }
        public string Salt { get; set; }
        public string Hash { get; set; }
        public DateTime AnlegeDatum { get; set; }
        public byte Aktiv { get; set; }
        public string Vorname { get; set; }
        public string Nachname { get; set; }
        public DateTime? Geburtsdatum { get; set; }
        public int? Alter { get; set; }

        public virtual ICollection<Bestellungen> Bestellungen { get; set; }
        public virtual ICollection<FhAngehörige> FhAngehörige { get; set; }
        public virtual ICollection<Freunde> FreundeFreundNavigation { get; set; }
        public virtual ICollection<Freunde> FreundeNutzerNavigation { get; set; }
        public virtual ICollection<Gäste> Gäste { get; set; }
    }
}
