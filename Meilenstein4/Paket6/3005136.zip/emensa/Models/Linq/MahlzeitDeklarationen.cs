﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class MahlzeitDeklarationen
    {
        public string FkDeklaration { get; set; }
        public int FkMahlzeit { get; set; }
        public int Id { get; set; }

        public virtual Deklarationen FkDeklarationNavigation { get; set; }
        public virtual Mahlzeiten FkMahlzeitNavigation { get; set; }
    }
}
