﻿using System;
using System.Collections.Generic;

namespace emensa.Models.Linq
{
    public partial class Student
    {
        public Student()
        {
            Kommentare = new HashSet<Kommentare>();
        }

        public int StudentId { get; set; }
        public string Studiengang { get; set; }
        public int Matrikelnummer { get; set; }
        public int FkFhange { get; set; }

        public virtual FhAngehörige FkFhangeNavigation { get; set; }
        public virtual ICollection<Kommentare> Kommentare { get; set; }
    }
}
